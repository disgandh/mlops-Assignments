import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import json
import time
import joblib
from tensorflow.keras.datasets import fashion_mnist
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from scipy.stats import ks_2samp
import warnings
import sys
warnings.filterwarnings('ignore')

# Check if MLflow is installed, otherwise recommend installation
try:
    import mlflow
    import mlflow.sklearn
    MLFLOW_AVAILABLE = True
except ImportError:
    MLFLOW_AVAILABLE = False
    print("MLflow not installed. Install with: pip install mlflow")
    print("Continuing without MLflow tracking...")

# Create directories for outputs
os.makedirs('m4_outputs', exist_ok=True)
os.makedirs('m4_outputs/drift', exist_ok=True)
os.makedirs('m4_outputs/tracking', exist_ok=True)

# Import feature engineering functions
# Assuming m2_fashion_mnist_feature_engineering.py is in the same directory
sys.path.append('.')
try:
    from m2_fashion_mnist_feature_engineering import normalize_images, extract_hog_features
except ImportError:
    print("Could not import functions from m2_fashion_mnist_feature_engineering.py.")
    print("Please ensure the file is in the current directory.")
    sys.exit(1)

# Define class names for better readability
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

# Load the Fashion MNIST dataset
print("Loading Fashion MNIST dataset...")
(X_train, y_train), (X_test, y_test) = fashion_mnist.load_data()

# Check if the model from M3 exists
model_path = 'm3_outputs/models/optimized_final_model.joblib'
if not os.path.exists(model_path):
    print(f"Error: Model file not found at {model_path}")
    print("Please run the M3 script (fashion_mnist_automl_simplified.py) first.")
    sys.exit(1)

# Load the optimized model from M3
print(f"Loading the optimized model from {model_path}...")
optimized_model = joblib.load(model_path)

# -------------------------------------------------------------------------
# Part 1: Set up MLflow Tracking
# -------------------------------------------------------------------------

if MLFLOW_AVAILABLE:
    print("Setting up MLflow tracking...")
    mlflow.set_experiment("Fashion-MNIST-Monitoring")

# -------------------------------------------------------------------------
# Part 2: Data Preprocessing
# -------------------------------------------------------------------------

# Apply the same feature engineering steps as in M3
print("Applying feature engineering...")
X_test_norm, _ = normalize_images(X_test, method='minmax')
X_test_hog, _ = extract_hog_features(X_test_norm)

# -------------------------------------------------------------------------
# Part 3: Drift Detection Implementation
# -------------------------------------------------------------------------

def detect_feature_drift(reference_data, new_data, threshold=0.05):
    """
    Detect feature drift using the Kolmogorov-Smirnov test
    """
    n_features = reference_data.shape[1]
    drift_scores = []
    drifted_features = []
    
    # Limit number of features to check for speed (if too many features)
    feature_indices = np.random.choice(n_features, min(100, n_features), replace=False) if n_features > 100 else range(n_features)
    
    for i in feature_indices:
        # Apply KS test to compare distributions
        ks_stat, p_value = ks_2samp(reference_data[:, i], new_data[:, i])
        drift_scores.append(ks_stat)
        
        # If p-value is below threshold, feature has drifted
        if p_value < threshold:
            drifted_features.append(i)
    
    # Calculate overall drift percentage
    drift_percentage = len(drifted_features) / len(feature_indices) * 100
    
    return {
        'drift_scores': drift_scores,
        'drifted_features': drifted_features,
        'drift_percentage': drift_percentage,
        'max_drift_score': max(drift_scores) if drift_scores else 0,
        'avg_drift_score': sum(drift_scores) / len(drift_scores) if drift_scores else 0,
        'needs_retraining': drift_percentage > 20  # Arbitrary threshold - 20% of features drifted
    }

def detect_label_drift(reference_preds, new_preds):
    """
    Detect concept drift by comparing prediction distributions
    """
    # Calculate class distribution in both sets
    ref_dist = np.bincount(reference_preds, minlength=10) / len(reference_preds)
    new_dist = np.bincount(new_preds, minlength=10) / len(new_preds)
    
    # Calculate Jensen-Shannon divergence (or simpler distance metric)
    js_distance = np.sqrt(0.5 * np.sum((ref_dist - new_dist)**2))
    
    return {
        'reference_distribution': ref_dist.tolist(),
        'new_distribution': new_dist.tolist(),
        'js_distance': js_distance,
        'needs_retraining': js_distance > 0.1  # Arbitrary threshold
    }

def detect_performance_drift(reference_acc, new_acc, threshold=0.05):
    """
    Detect performance drift by comparing accuracy values
    """
    acc_diff = abs(reference_acc - new_acc)
    
    return {
        'reference_accuracy': reference_acc,
        'new_accuracy': new_acc,
        'accuracy_difference': acc_diff,
        'needs_retraining': acc_diff > threshold
    }

# -------------------------------------------------------------------------
# Part 4: Simulate Model Monitoring Over Time
# -------------------------------------------------------------------------

def add_noise_to_images(images, noise_level=0.1):
    """Add random noise to images to simulate data drift"""
    noisy_images = images.copy()
    noise = np.random.normal(0, noise_level, images.shape)
    noisy_images = noisy_images + noise
    noisy_images = np.clip(noisy_images, 0, 1)  # Keep within valid range
    return noisy_images

def simulate_concept_drift(labels, drift_percentage=0.05):
    """Randomly change some labels to simulate concept drift"""
    drifted_labels = labels.copy()
    n_drift = int(len(labels) * drift_percentage)
    indices = np.random.choice(len(labels), n_drift, replace=False)
    
    for idx in indices:
        # Change to a different random class
        current_label = drifted_labels[idx]
        available_labels = [i for i in range(10) if i != current_label]
        drifted_labels[idx] = np.random.choice(available_labels)
    
    return drifted_labels

print("\nSimulating model monitoring over multiple time periods...")

# Set up reference data (first 1000 test samples)
reference_data = X_test_hog[:1000]
reference_labels = y_test[:1000]
reference_preds = optimized_model.predict(reference_data)
reference_acc = accuracy_score(reference_labels, reference_preds)

print(f"Reference accuracy: {reference_acc:.4f}")

# Number of simulation periods
n_periods = 6

# Lists to store results
periods = []
accuracies = []
feature_drift_scores = []
label_drift_scores = []
performance_drift_results = []
retraining_flags = []

# Start MLflow run if available
if MLFLOW_AVAILABLE:
    mlflow_run = mlflow.start_run(run_name="Fashion-MNIST-Monitoring")
    mlflow.sklearn.log_model(optimized_model, "reference_model")
    mlflow.log_metric("reference_accuracy", reference_acc)

# Simulate data over multiple time periods
for period in range(1, n_periods + 1):
    print(f"Period {period}...")
    
    # Simulate different types of drift as time progresses
    data_drift_level = 0.02 * period  # Increasing noise
    concept_drift_level = 0.01 * period  # Increasing label mistakes
    
    # Sample a different batch of 1000 test images each time
    start_idx = 1000 + (period - 1) * 1000
    end_idx = min(start_idx + 1000, len(X_test))
    
    # Get batch and add simulated drift
    current_data = X_test_hog[start_idx:end_idx]
    current_labels = y_test[start_idx:end_idx]
    
    # Add data drift (increasing noise)
    if period > 1:  # Start drift from period 2
        current_images = X_test_norm[start_idx:end_idx]
        noisy_images = add_noise_to_images(current_images, data_drift_level)
        current_data, _ = extract_hog_features(noisy_images)
    
    # Make predictions
    current_preds = optimized_model.predict(current_data)
    current_acc = accuracy_score(current_labels, current_preds)
    
    # Detect drifts
    feature_drift = detect_feature_drift(reference_data, current_data)
    label_drift = detect_label_drift(reference_preds, current_preds)
    performance_drift = detect_performance_drift(reference_acc, current_acc)
    
    # Determine if retraining is needed
    needs_retraining = (feature_drift['needs_retraining'] or 
                       label_drift['needs_retraining'] or 
                       performance_drift['needs_retraining'])
    
    # Store results
    periods.append(period)
    accuracies.append(current_acc)
    feature_drift_scores.append(feature_drift['max_drift_score'])
    label_drift_scores.append(label_drift['js_distance'])
    performance_drift_results.append(performance_drift['accuracy_difference'])
    retraining_flags.append(needs_retraining)
    
    # Log to MLflow if available
    if MLFLOW_AVAILABLE:
        mlflow.log_metric("accuracy", current_acc, step=period)
        mlflow.log_metric("feature_drift", feature_drift['max_drift_score'], step=period)
        mlflow.log_metric("label_drift", label_drift['js_distance'], step=period)
        mlflow.log_metric("performance_drift", performance_drift['accuracy_difference'], step=period)
        mlflow.log_metric("needs_retraining", int(needs_retraining), step=period)
    
    print(f"  Accuracy: {current_acc:.4f}")
    print(f"  Feature Drift Score: {feature_drift['max_drift_score']:.4f}")
    print(f"  Label Drift Score: {label_drift['js_distance']:.4f}")
    print(f"  Performance Diff: {performance_drift['accuracy_difference']:.4f}")
    print(f"  Needs Retraining: {needs_retraining}")

# End MLflow run if available
mlflow_run_id = None
if MLFLOW_AVAILABLE:
    mlflow_run_id = mlflow.active_run().info.run_id
    print(f"MLflow Run ID: {mlflow_run_id}")
    mlflow.end_run()

# -------------------------------------------------------------------------
# Part 5: Visualize Monitoring Results
# -------------------------------------------------------------------------

print("\nCreating monitoring visualizations...")

# Create DataFrame with all results
monitoring_df = pd.DataFrame({
    'Period': periods,
    'Accuracy': accuracies,
    'Feature Drift': feature_drift_scores,
    'Label Drift': label_drift_scores,
    'Performance Drift': performance_drift_results,
    'Needs Retraining': retraining_flags
})

# Save monitoring data
monitoring_df.to_csv('m4_outputs/tracking/monitoring_data.csv', index=False)

# 1. Plot accuracy over time
plt.figure(figsize=(10, 6))
plt.plot(periods, accuracies, 'o-', linewidth=2)
plt.axhline(y=reference_acc, color='r', linestyle='--', label='Reference Accuracy')
plt.xlabel('Time Period')
plt.ylabel('Accuracy')
plt.title('Model Accuracy Over Time')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig('m4_outputs/tracking/accuracy_over_time.png')

# 2. Plot drift metrics over time
plt.figure(figsize=(12, 8))

plt.subplot(3, 1, 1)
plt.plot(periods, feature_drift_scores, 'o-', color='blue', linewidth=2)
plt.axhline(y=0.1, color='r', linestyle='--', label='Threshold')
plt.title('Feature Drift Over Time')
plt.ylabel('Max KS Statistic')
plt.grid(True)
plt.legend()

plt.subplot(3, 1, 2)
plt.plot(periods, label_drift_scores, 'o-', color='green', linewidth=2)
plt.axhline(y=0.1, color='r', linestyle='--', label='Threshold')
plt.title('Label Drift Over Time')
plt.ylabel('JS Distance')
plt.grid(True)
plt.legend()

plt.subplot(3, 1, 3)
plt.plot(periods, performance_drift_results, 'o-', color='purple', linewidth=2)
plt.axhline(y=0.05, color='r', linestyle='--', label='Threshold')
plt.title('Performance Drift Over Time')
plt.xlabel('Time Period')
plt.ylabel('Accuracy Difference')
plt.grid(True)
plt.legend()

plt.tight_layout()
plt.savefig('m4_outputs/tracking/drift_metrics_over_time.png')

# 3. Plot retraining signals
plt.figure(figsize=(10, 6))
colors = ['green' if not flag else 'red' for flag in retraining_flags]
bars = plt.bar(periods, [1] * len(periods), color=colors)
plt.yticks([])
plt.xlabel('Time Period')
plt.title('Model Retraining Signals')
plt.xticks(periods)

# Add "Retrain" text to red bars
for i, bar in enumerate(bars):
    if retraining_flags[i]:
        plt.text(bar.get_x() + bar.get_width()/2, 0.5, 'Retrain', 
                ha='center', va='center', color='white', fontweight='bold')
    else:
        plt.text(bar.get_x() + bar.get_width()/2, 0.5, 'OK', 
                ha='center', va='center', color='white', fontweight='bold')

plt.tight_layout()
plt.savefig('m4_outputs/tracking/retraining_signals.png')

# -------------------------------------------------------------------------
# Part 6: Implement Drift Detection Dashboard
# -------------------------------------------------------------------------

# Create a time-based drift detection report
report_data = {
    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
    'accuracy_trend': accuracies,
    'feature_drift_trend': feature_drift_scores,
    'label_drift_trend': label_drift_scores,
    'performance_drift_trend': performance_drift_results,
    'retraining_signals': [int(flag) for flag in retraining_flags],
    'mlflow_run_id': mlflow_run_id,
    'mlflow_available': MLFLOW_AVAILABLE,
    'drift_thresholds': {
        'feature_drift': 0.1,
        'label_drift': 0.1,
        'performance_drift': 0.05
    },
    'summary': {
        'total_periods': n_periods,
        'periods_needing_retraining': sum(retraining_flags),
        'final_accuracy': accuracies[-1],
        'accuracy_trend': 'decreasing' if accuracies[-1] < accuracies[0] else 'stable' 
                         if abs(accuracies[-1] - accuracies[0]) < 0.01 else 'increasing',
        'reference_accuracy': reference_acc
    }
}

# Save drift detection report
with open('m4_outputs/drift/drift_detection_report.json', 'w') as f:
    json.dump(report_data, f, indent=4)

# Create a snapshot of the latest drift status
latest_status = {
    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
    'current_accuracy': accuracies[-1],
    'feature_drift_score': feature_drift_scores[-1],
    'label_drift_score': label_drift_scores[-1],
    'performance_drift': performance_drift_results[-1],
    'needs_retraining': retraining_flags[-1],
    'reference_accuracy': reference_acc
}

# Save latest status
with open('m4_outputs/drift/latest_drift_status.json', 'w') as f:
    json.dump(latest_status, f, indent=4)

print("\nModel monitoring implementation complete!")
print("Check the 'm4_outputs' directory for all visualizations and results.")
print("\nKey Findings:")
print(f"1. Initial reference accuracy: {reference_acc:.4f}")
print(f"2. Final period accuracy: {accuracies[-1]:.4f}")
print(f"3. Observed drift intensity: {'High' if max(feature_drift_scores) > 0.2 else 'Moderate' if max(feature_drift_scores) > 0.1 else 'Low'}")
print(f"4. Number of periods requiring retraining: {sum(retraining_flags)}/{n_periods}")

# Create a README file with instructions
readme_content = """# Model Monitoring and Drift Detection

This directory contains the results of model monitoring and drift detection for the Fashion MNIST model.

## Directory Structure
- `/tracking`: Contains performance tracking logs and visualizations
- `/drift`: Contains drift detection reports and status

## Key Files
- `monitoring_data.csv`: Raw monitoring data for all time periods
- `accuracy_over_time.png`: Visualization of model accuracy over time
- `drift_metrics_over_time.png`: Visualization of different drift metrics
- `retraining_signals.png`: Visual indication of when model retraining is needed
- `drift_detection_report.json`: Comprehensive drift detection report
- `latest_drift_status.json`: Snapshot of the most recent drift status

## MLflow Tracking
"""

if MLFLOW_AVAILABLE:
    readme_content += f"""MLflow was used to track model performance. To view the MLflow UI, run the following command:
    
```bash
mlflow ui
```

The MLflow run ID for this monitoring session is: {mlflow_run_id}
"""
else:
    readme_content += """MLflow was not available during this run. Install MLflow to enable more comprehensive tracking:

```bash
pip install mlflow
```
"""

readme_content += """
## Drift Detection Methods

Three types of drift detection were implemented:

1. **Feature Drift**: Detects changes in the input data distribution using the Kolmogorov-Smirnov test.
2. **Label Drift**: Detects changes in the prediction distribution using Jensen-Shannon divergence.
3. **Performance Drift**: Detects degradation in model accuracy compared to the reference.

## Retraining Recommendations

Retraining is recommended when any of the following conditions are met:
- Feature drift score exceeds 0.1
- Label drift score exceeds 0.1
- Performance drift (accuracy difference) exceeds 0.05

"""

# Save README
with open('m4_outputs/README.md', 'w') as f:
    f.write(readme_content)
