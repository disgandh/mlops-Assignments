# Model Monitoring and Drift Detection

This directory contains the results of model monitoring and drift detection for the Fashion MNIST model.

## Directory Structure
- `/tracking`: Contains performance tracking logs and visualizations
- `/drift`: Contains drift detection reports and status

## Key Files
- `monitoring_data.csv`: Raw monitoring data for all time periods
- `accuracy_over_time.png`: Visualization of model accuracy over time
- `drift_metrics_over_time.png`: Visualization of different drift metrics
- `retraining_signals.png`: Visual indication of when model retraining is needed
- `drift_detection_report.json`: Comprehensive drift detection report
- `latest_drift_status.json`: Snapshot of the most recent drift status

## MLflow Tracking
MLflow was used to track model performance. To view the MLflow UI, run the following command:
    
```bash
mlflow ui
```

The MLflow run ID for this monitoring session is: 3d24a6a074594695858870fa7e39c429

## Drift Detection Methods

Three types of drift detection were implemented:

1. **Feature Drift**: Detects changes in the input data distribution using the Kolmogorov-Smirnov test.
2. **Label Drift**: Detects changes in the prediction distribution using Jensen-Shannon divergence.
3. **Performance Drift**: Detects degradation in model accuracy compared to the reference.

## Retraining Recommendations

Retraining is recommended when any of the following conditions are met:
- Feature drift score exceeds 0.1
- Label drift score exceeds 0.1
- Performance drift (accuracy difference) exceeds 0.05

